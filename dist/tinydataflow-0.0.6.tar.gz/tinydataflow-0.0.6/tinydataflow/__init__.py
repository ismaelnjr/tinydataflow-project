__version__ = '0.0.6'

from tinydataflow.core import TinyDataFlow